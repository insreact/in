// Include head scripts in the right order
// They will be concatenated using gulp-rigger in head.min.js

//= lib/progress.js
